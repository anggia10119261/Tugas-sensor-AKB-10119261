package com.anggia.makanku10119261.view.carimakan;
/*
    nim                 : 10119261
    nama                : Anggia Regina Wulandari
    kelas               : IF-7
*/
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import com.anggia.makanku10119261.R;


public class CariMakanFragment extends Fragment implements OnMapReadyCallback{
    private GoogleMap mMap;

    public CariMakanFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_cari_kuliner, container, false);
        SupportMapFragment mMapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.carikulinermap);
        mMapFragment.getMapAsync(this);
        return view;
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Bandung and move the camera
        LatLng bukit_scooter = new LatLng(-7.196913043216491, 109.90626509184716);
        LatLng dieng_plateau = new LatLng(-7.199601837540079, 109.90008949406143);
        LatLng negeri_atas_awan = new LatLng(-7.20202731421282, 109.9071317874022);
        LatLng arjuna_temple = new LatLng(-7.204651183590399, 109.90678682087918);
        LatLng candi_drawati = new LatLng(-7.197007695707707, 109.91094941692364);

        mMap.addMarker(new MarkerOptions().position(bukit_scooter).title("Bukit Scooter"));
        mMap.addMarker(new MarkerOptions().position(dieng_plateau).title("Dieng Plateau"));
        mMap.addMarker(new MarkerOptions().position(negeri_atas_awan).title("Negeri Atas Awan"));
        mMap.addMarker(new MarkerOptions().position(arjuna_temple).title("Arjuna Temple"));
        mMap.addMarker(new MarkerOptions().position(candi_drawati).title("Candi Dwarawati"));

        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(negeri_atas_awan, 14));

    }
}